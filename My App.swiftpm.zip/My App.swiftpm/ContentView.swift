import SwiftUI

struct ContentView: View {
    @State private var wordToGuess = "SWIFT"
    @State private var guessedLetters: [String] = []
    @State private var incorrectGuesses = 0
    @State private var remainingTries = 6
    
    private var displayedWord: String {
        wordToGuess.map { guessedLetters.contains(String($0)) ? String($0) : "_" }.joined(separator: " ")
    }
    
    private let alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Hangman Game")
                .font(.largeTitle)
                .fontWeight(.bold)
            
            Text("Tries Left: \(remainingTries)")
                .font(.headline)
                .foregroundColor(remainingTries > 0 ? .green : .red)
            
            Text(displayedWord)
                .font(.system(size: 36, weight: .bold, design: .monospaced))
            
            if remainingTries == 0 || displayedWord.replacingOccurrences(of: " ", with: "") == wordToGuess {
                Text(remainingTries == 0 ? "Game Over! The word was \(wordToGuess)." : "You Win!")
                    .font(.headline)
                    .foregroundColor(.blue)
                
                Button("Restart Game") {
                    resetGame()
                }
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
            } else {
                LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 7), spacing: 10) {
                    ForEach(alphabet.map { String($0) }, id: \.self) { letter in
                        Button(letter) {
                            letterTapped(letter)
                        }
                        .padding()
                        .background(guessedLetters.contains(letter) ? Color.gray : Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                        .disabled(guessedLetters.contains(letter))
                    }
                }
                .padding()
            }
        }
        .padding()
    }
    
    func letterTapped(_ letter: String) {
        guessedLetters.append(letter)
        if !wordToGuess.contains(letter) {
            incorrectGuesses += 1
            remainingTries -= 1
        }
    }
    
    func resetGame() {
        wordToGuess = ["SWIFT", "APPLE", "PROGRAM"].randomElement() ?? "SWIFT"
        guessedLetters = []
        incorrectGuesses = 0
        remainingTries = 6
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
